

<?php $__env->startSection('content'); ?>

<div style = "background-color:#F1EAE8">
	<style> 

    body{
    	border: 4px solid black;
    		border-radius: 4px;
    		padding: 5px;
    }

</style>

	<img src="/logo.jpg"   width="100" height="100">

	 <table border="10" width="1000">
	 	
	 	<tr>
            <th> <a href='index' style="text-decoration:none;"> <p style="font-size:20px"> Home </p></a> </th> 

         	<th> <a href='create' style="text-decoration:none;"> <p style="font-size:20px"> Add Member </p></a> </th>
         	
         	<th> <a href='members' style="text-decoration:none;"> <p style="font-size:20px"> Member's Detail </p></a> </th>
  	
         	<th> <a href='coach' style="text-decoration:none;"> <p style="font-size:20px"> Coach </p></a> </th>

         </tr>

	 </table> 

	
</div>


<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/header.blade.php ENDPATH**/ ?>