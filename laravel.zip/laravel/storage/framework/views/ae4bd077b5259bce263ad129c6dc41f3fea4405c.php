

<?php $__env->startSection('content'); ?>

<div>
</div>






<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/book.blade.php ENDPATH**/ ?>