

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('students.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div>


        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div style = "background-color:#F1EAE8">
	<br><br>
	<br><br>
    
	<center><form action="<?php echo e(route('students.store')); ?>" method="POST">
 	 	<?php echo csrf_field(); ?>
 	 	
		 <input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)"> 
		<br>
		 <input type="text" name="name" placeholder="Full Name">
		<br>

		  <input type="text" name="batch" placeholder="Batch">
          <br>

		    <input type="text" name="sports_name" placeholder="Sports_name">

		<br><br>
		<button type="submit" >Enter</button>

	</form>
</center>

<br>
	<br><br>
	<br><br>
	<br><br>
	


</div>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/create.blade.php ENDPATH**/ ?>