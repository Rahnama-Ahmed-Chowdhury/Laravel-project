

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('students.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div style = "background-color:#F1EAE8">
	<br><br>
	<center><div class="table-wrapper" style="width: 800px">
  	<div class="md-card-content" style="height:400px;overflow-y:scroll">

	<table border="10" width="780">
		<tr>
			
			<th><p style="font-size:20px">Student ID</p> </th>
			<th> <p style="font-size:20px">Full Name</p> </th>
			<th> <p style="font-size:20px">Batch</p> </th>
			<th> <p style="font-size:20px">Sports Name</p> </th>


		</tr>

		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr> 
			<td><?php echo e($student->student_id); ?> </td>
			<td><?php echo e($student->name); ?> </td>
			<td><?php echo e($student->batch); ?> </td>
			<td><?php echo e($student->sports_name); ?> </td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

	</table>

</div>
</div>
</center>

<br>
<br>
<br>
<br>
<br>
</div>





<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/members.blade.php ENDPATH**/ ?>