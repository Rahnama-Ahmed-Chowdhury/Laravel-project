

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('students.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style = "background-color:#F1EAE8">
	
	<br>
	<br>
	<br>
	<br>
   <div class="row">
    <style>
    	.cri{
    		width:200px;
    		height:200px;
    		margin-left: 35px;
    		margin-top: ;
    		border: 1px solid black;
    		border-radius: 4px;
    		padding: 5px;
    	}

    	.fot{
    	       width:200px;
    		height:200px;
    		margin-left: 100px ;
    		margin-top: ;
    		border: 1px solid black;
    		border-radius: 4px;
    		padding: 5px;	
    	}
    	.bad{
    		width:200px;
    		height:200px;
    		margin-left: 100px;
    		margin-top: ;
    		border: 1px solid black;
    		border-radius: 4px;
    		padding: 5px;
    	}
    	.hoc{
    		width:200px;
    		height:200px;
    		margin-left: 100px;
    		margin-top: ;
    		border: 1px solid black;
    		border-radius: 4px;
    		padding: 5px;
    	}
    </style>

   	<a href="https://en.wikipedia.org/wiki/Cricket"><img src="/Cricket.jpg"   class="cri"></a>
   	
   	<a href="https://en.wikipedia.org/wiki/Football"><img src="/football.jpg"   class="fot"></a>   
   	<a href="https://en.wikipedia.org/wiki/Badminton"><img src="/badminton.jpg"   class="bad"></a>
   	<a href="https://en.wikipedia.org/wiki/Hockey"><img src="/hockey.jpg"   class="hoc"></a>

   </div>

	 <br>
	 	 <br>
	 	 	 <br>
	 	 	 	 <br>
	 	 	 	 	 <br>
	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 	 	 	 	 	 	 <br>
	 	 	 	 	 	 	 	 	 	 	 	 	 	 <br> 
	  <br> 
	   <br> 
	    <br> 
	     <br>     
	
</div>


<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/index.blade.php ENDPATH**/ ?>