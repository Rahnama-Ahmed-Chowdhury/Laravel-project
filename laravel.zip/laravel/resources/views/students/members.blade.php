@extends('students.layout')

@section('content')
	@include('students.header')
@section('content')

<div style = "background-color:#F1EAE8">
	<br><br>
	<center><div class="table-wrapper" style="width: 800px">
  	<div class="md-card-content" style="height:400px;overflow-y:scroll">

	<table border="10" width="780">
		<tr>
			
			<th><p style="font-size:20px">Student ID</p> </th>
			<th> <p style="font-size:20px">Full Name</p> </th>
			<th> <p style="font-size:20px">Batch</p> </th>
			<th> <p style="font-size:20px">Sports Name</p> </th>


		</tr>

		@foreach ($students as $student)
		<tr> 
			<td>{{$student->student_id}} </td>
			<td>{{$student->name}} </td>
			<td>{{$student->batch}} </td>
			<td>{{$student->sports_name}} </td>
		</tr>
		@endforeach 

	</table>

</div>
</div>
</center>

<br>
<br>
<br>
<br>
<br>
</div>




