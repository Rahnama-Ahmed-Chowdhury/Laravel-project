  <html>
<head> 
  <title> CSE 323: Web Programming Laravel Project</title>
</head>
<body>
  <div class="container"> 
    @yield('content')
  </div>

</body>
</html>