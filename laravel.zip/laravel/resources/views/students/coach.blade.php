@extends('students.layout')
@section('content')
	@include('students.header')
@section('content')

<div style = "background-color:#F1EAE8">

<br>
<center><div class="table-wrapper" style="width: 850px">
  	<div class="md-card-content" style="height:400px;overflow-y:scroll">
	<table border="10" width="800">
		<tr>
			<th> Student ID </th>
			<th> Full Name </th>
			<th> Batch </th>
			<th> Sports Name </th>
			<th> Action </th>
		</tr>

		@foreach ($students as $student)
		<tr> 
			<td>{{$student->student_id}} </td>
			<td>{{$student->name}} </td>
			<td>{{$student->batch}} </td>
			<td>{{$student->sports_name}} </td>
			<td>
				<center><button type="submit" > <a href="{{ route('students.edit', $student->id)}}" style="text-decoration:none;"> Edit </a> </button>

				<form action="{{ route('students.destroy', $student->id)}}" method="POST">
										
					@csrf
                    @method('DELETE') 

					<button type="submit" > Delete </button>
				</form>
			</td>
		</tr>
		@endforeach 

	</table>
</div>
</div>
</center>
<br>

</div>
