@extends('students.layout')

@section('content')

<div style = "background-color:#F1EAE8">

	 <center><h1> Library Management System </h1></center>

	<br>
	<div style = "position:relative; left:1100px; top:3px">

	<a href="{{ route('students.create') }}"><p style="font-size:20px">Register Student</p></a>
    
    </div>
	<br>
	<hr>

    <center>
	<table border="2" width="800">
		<tr>
			
			<th><p style="font-size:20px">Student ID</p> </th>
			<th> <p style="font-size:20px">Full Name</p> </th>
			<th> <p style="font-size:20px">Batch</p> </th>
			<th> <p style="font-size:20px">Action</th>
		
		</tr>

		@foreach ($students as $student)
		<tr> 
			<td>{{$student->student_id}} </td>
			<td>{{$student->name}} </td>
			<td>{{$student->batch}} </td>
			<td>
				<form action="{{ route('students.destroy', $student->id)}}" method="POST">
					<a href="{{ route('students.edit', $student->id)}}" > Edit </a>					
					@csrf
                    @method('DELETE') 

					<button type="submit" > Delete </button>
				</form>
			</td>
		</tr>
		@endforeach 

	</table>
</center>

</div>





