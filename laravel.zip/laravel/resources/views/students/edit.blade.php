@extends('students.layout')
@section('content')
	@include('students.header')
@section('content')
@if ($errors->any())
    <div>
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<div style = "background-color:#F1EAE8">
<br>
	<center><form action="{{route('students.update',$student->id) }}" method="POST">
 	 	@csrf
 	 	@method('PUT')
 	 	
		Student ID:<input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)" value="{{$student->student_id}}"> 
		<br>
		Student Name:<input type="text" name="name" placeholder="Full Name"
		 value="{{$student->name}}">
		<br>

		Student Batch: <input type="text" name="batch" placeholder="Batch" value="{{$student->batch}}">
		<br> 
            
          Sports Name: <input type="text" name="sports_name" placeholder="Sports_name" value="{{$student->sports_name}}">

		<br>
		<button type="submit" >Update</button>

	</form>
</center>
              <br>
              <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</div>