@extends('students.layout')

@section('content')
	@include('students.header')
@section('content')
@if ($errors->any())
    <div>


        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div style = "background-color:#F1EAE8">
	<br><br>
	<br><br>
    
	<center><form action="{{route('students.store')}}" method="POST">
 	 	@csrf
 	 	
		 <input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)"> 
		<br>
		 <input type="text" name="name" placeholder="Full Name">
		<br>

		  <input type="text" name="batch" placeholder="Batch">
          <br>

		    <input type="text" name="sports_name" placeholder="Sports_name">

		<br><br>
		<button type="submit" >Enter</button>

	</form>
</center>

<br>
	<br><br>
	<br><br>
	<br><br>
	


</div>